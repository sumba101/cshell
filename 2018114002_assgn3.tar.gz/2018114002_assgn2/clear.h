bool clear(const size_t argc,char **argv){
    printf ("\033c");
    return false;
}
